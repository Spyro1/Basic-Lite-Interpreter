//
// Created by Szenes Márton on 2024. 03. 14..
//

#include "List.h"

template<class C>
List<C>::List() {
    first = nullptr;
    Count = 0;
}

template<class C>
List<C>::List(const List &copy) {
    Count = copy.Count;
    // TODO: Copy constructor of List
}
template<class C>
List<C> &List<C>::operator=(const List &right) {
    if (this != &right){

    }
    return *this;
    // TODO: Copy Value maker constructor of List
}

template<class C>
void List<C>::Initialize() {

}
template<class C>
void List<C>::Add(C newItem) {
    // Empty list
    if (first == nullptr){
        first = new Node<C>();
        first->data = newItem;
        first->next = nullptr;
    }
    else{
        Node<C>* iter = first;
        while(iter != nullptr) iter = iter->next;

    }
}
template<class C>
void List<C>::InsertAt(size_t index) {

}
template<class C>
bool List<C>::RemoveAt(size_t index) {
    // TODO: RemoveAt List function
    return false;
}
template<class C>
bool List<C>::RemoveLast() {
    // TODO: RemoveLast List function
    return false;
}


template<class C>
C& List<C>::operator[](size_t index) {
    if (index > Count)
        throw "Error: Index out of range";
    Node<C>* iter = first;
    for (int i = 0; i < index; ++i) {
        iter = iter->next;
    }
    return iter->data;
}

template<class C>
List<C>::~List() {
    Node<C>* iter = first;
    while(iter != nullptr){
        Node<C>* nextNode = iter->next;
        delete iter;
        iter = nextNode;
    }
}
