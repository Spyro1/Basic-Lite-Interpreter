//
// Created by Szenes Márton on 2024. 03. 14..
//

#ifndef NAGYHAZI_LIST_H
#define NAGYHAZI_LIST_H

#include <cstdlib>


template <class C>
struct Node { C data; Node<C>* next; };

template <class C>
class List {
    Node<C>* first;
public:
    size_t Count;

    List();
    List<C>(const List& rhs);
    List<C>& operator=(const List& rhs);

    void Initialize();
    void Add(C newItem);
    void InsertAt(size_t index);
    bool RemoveAt(size_t index);
    bool RemoveLast();
    C& operator[](size_t index);

    ~List();
};



#endif //NAGYHAZI_LIST_H
