//
// Created by Szenes Márton on 2024. 03. 14..
//
#include <fstream>
#include "Computer.h"

//size_t Computer::RegisterCount = 2; // default value

Computer::Computer(size_t registerCount) {
    if (registerCount <  2) throw "Error: There are not enough registers for computer to work."; // Computer can not work with less than 2 registers. (PLAN)

    registers.Add(Register("a")); // Base register
    registers.Add(Register("i")); // Counter


//    registers = List<Register>();
//    instructions = List<Instruction>();

//    instructions = new List<Instruction>();
//    registers = new Register[registerCount];
}

void Computer::ReadProgramFromFile(const char *filename) {
    using namespace std;
    // If this computer has read a program before, then free dynamic memory from registers and istructions
    DeleteProgramArrays();
    // Read file
    fstream filereader;
    filereader.open(filename,ios::in); // Open file
    // If file doesn't exist, then throw exception
    if (!filereader.is_open()){
        filereader.close();
        throw string("Error: File not found!");
    }
    // File was opened

    // TODO: Make file reading line by line

    filereader.close();
}
void Computer::RunProgram() {

}

void Computer::ExecuteNextInstruction() {

}

void Computer::DeleteProgramArrays() {
//    if (instructionIndex != -1){
//        delete[] registers;
////        delete instructions;
//    }
}
Computer::~Computer() {
    DeleteProgramArrays();
}




